package models;

import org.bson.types.ObjectId;

import play.modules.morphia.Model;

import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;


@SuppressWarnings("serial")
public abstract class Base extends Model {
}
